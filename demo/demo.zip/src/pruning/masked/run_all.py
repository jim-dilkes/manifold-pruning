import os

os.system("python3 run_mac.py")
os.system("python3 run_latency.py")
